//
// Created by Erasmo on 26/05/25.
//

#ifndef CADENAS_UTILS_HPP
#define CADENAS_UTILS_HPP
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#define ANCHO_REPORTE 120
#define N_COLUMNAS 4
#define NO_ENCONTRADO -1
using namespace std;
#endif //CADENAS_UTILS_HPP
